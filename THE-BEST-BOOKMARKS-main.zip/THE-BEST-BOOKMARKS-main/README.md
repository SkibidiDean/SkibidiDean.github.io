# OLD GITHUB ACCOUNT GOT DELETED SO I REUPLOADED
how to use:
1. download the .html file
2. go to chrome://bookmarks
3. click the three dots
4. click import bookmarks
5. click the file you downloaded
6. a new folder will appear and drag the folder called "THE BEST" out of it
7. its ready to use!
